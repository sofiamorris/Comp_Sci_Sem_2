import pkg.*;
import java.util.*;
import javax.swing.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.Point;

public class Panel extends JPanel implements MouseListener, MouseMotionListener{
    private CTetriMino BlockToBeMoved;
	private int m_nOffsetX;
	private int m_nOffsetY;
	private Image backBuffer;
	private Graphics gBackBuffer;
	boolean isInitialized;
	public Panel()
	{
  	  isInitialized=false;
   	 this.addMouseListener(this);
   	 this.addMouseMotionListener(this);
	}
	public void mouseClicked( MouseEvent e ){
    if (e.isMetaDown()){
        for (int i=duplicates.size()-1; i>=0; i--) {
            if (duplicates.get(i).containPoint(e.getX(), e.getY())) {
                duplicates.remove(i);
                repaint();
                break;
            }
        }
    }
	}
	public void mousePressed( MouseEvent e ){
  	  if (e.isMetaDown()) return;
   		 for (int i=duplicates.size()-1; i>=0; i--) {
       	 CTetriMino p=duplicates.get(i);
       	 if (p.containPoint(e.getX(), e.getY())) {
        	    duplicates.remove(i);
          	  duplicates.add(p);  // move to the end, i.e. the top
          	  BlockToBeMoved=p;
           	 m_nOffsetX=e.getX()-BlockToBeMoved.getX();
          	  m_nOffsetY=e.getY()-BlockToBeMoved.getY();
          	  repaint();
          	  return;
      	  }
   	 	}
		for (int i=originals.size()-1; i>=0; i--) {
   	     CTetriMino p=originals.get(i);
     	   System.out.println(p.containPoint(e.getX(), e.getY()));
        	if (p.containPoint(e.getX(), e.getY())) {
           	 CTetriMino p2=new CTetriMino(p); // make a copy of p
           	 duplicates.add(p2); // add to the end
          	  BlockToBeMoved=p2;  // p2 is selected, to be moved
           	 m_nOffsetX=e.getX()-BlockToBeMoved.getX();
         	   m_nOffsetY=e.getY()-BlockToBeMoved.getY();
          	  repaint();
          	  return;
      	  }
   		 }
	}
	public void mouseReleased(MouseEvent e){
		BlockToBeMoved=null; // no shape selected
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseMoved(MouseEvent e){}
	public void mouseDragged(MouseEvent e){
    	if (e.isMetaDown()) return; // ignore right button
    	System.out.println(BlockToBeMoved);
    	if (BlockToBeMoved!=null){
        	BlockToBeMoved.setX(e.getX()-m_nOffsetX);
        	BlockToBeMoved.setY(e.getY()-m_nOffsetY);
        	repaint();
   		 }
	}
	public void jLabel1MousePressed(java.awt.event.MouseEvent evt){
		initialClick = evt.getPoint();
	}
	public void jLabel1MouseDragged(java.awt.event.MouseEvent evt){
		int thisX = jLabel1.getLocation().x;
		int thisY = jLabel1.getLocation().y;
		int xMoved = (thisX + evt.getX())  - (thisX + initialClick.x);
		int yMoved = (thisY + evt.getY()) - (thisY + initialCLick.y);
		int X = thisX + xMoved;
		int Y = thisY + yMoved;
		jLabel1.setLocation(X,Y);
		jLabel1.repaint();
	}

}