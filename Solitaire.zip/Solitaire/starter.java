import pkg.*;
import java.util.*;
import javax.swing.*;

class starter{
	public static void main(String args[]) {
		int w = 480;
		int h = 640;
		JFrame f = new JFrame();
		DrawingCanvas dc = new DrawingCanvas(w,h);
		Panel pan = new Panel();
		f.setSize(w,h);
		f.setTitle("Solitaire");
		f.add(dc);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);

		//https://www.youtube.com/watch?v=UXLOZshtC3I

		
	}
}
